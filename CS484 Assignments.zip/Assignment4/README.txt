Program:	texdemo		(Assignment 4)
Author:		Kyle Maysey
Email:		Kyle_Maysey@csu.fullerton.edu

Description:

	In this project we were introduced to texture mapping using both OpenGL fixed functionality as well as the mapping of
textures with shaders.  The shaders use the "naive" texture coordinates provided by the SurfaceGeometry class. The fixed
functionality utilizes the command glGenTex to generate texture cooridnates.


Controls:

	Left Click		- Translate in the x-y plane

	Shift + Left Click	- Translate in the x-z plane

	Control + Left Click 	- Translate in the z plane

	space			- Toggles translation of model and light source
	
	m			- Changes material used for coloring the model

	g			- Toggles the use of fixed functionality and shaders

	ESC			- Quit


How to run:

	**Originally compiled in windows using Visual Studio Express.  Used secondary libraries for glut and glew**
	**I've also provided the class I used to load the .ppm files**
	
	Compile code and execute program through desired means.

	commandline argument:	-v				--to display debug messages
				-x [File Path of .vs shader]	--load vertex shader
				-f [File Path of .fs shader]	--load fragment shader
				-t [File Path of .ppm texture]	--load texture for mapping

Example Commandline:

	"file path"/texdemo.exe -v -x "file path"/phong.vs -f "file path"/phong.fs -t "file path"/checker.ppm

	OR

	"file path"/texdemo.exe -v -x "file path"/phong.vs -f "file path"/phong2.fs -t "file path"/checker.ppm