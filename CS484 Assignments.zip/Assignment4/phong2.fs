//Assignment 3: GLSL
//Phong illumination - Fragment shader using Materials
//Author: Kyle Maysey

varying vec3 Normal, LightVec, ReflVec, Vert;

uniform sampler2D tex;

void main()
{
	vec4 color = vec4(0.0, 1.0, 0.0, 1.0);			//Vec4 to hold color attributes
	vec4 ambient = gl_FrontMaterial.ambient;		//Setting ambient color to a dim green
	float NdotL, EdotR;						//Variables used to store the dot products of variables

	vec3 EyeVec = normalize( -Vert );

	NdotL = max( dot(Normal, LightVec), 0.0);

	if(NdotL > 0.0)
	{
		EdotR = max( dot( EyeVec, ReflVec), 0.0);

		color = ambient + ( gl_FrontMaterial.diffuse * NdotL) +  ( gl_FrontMaterial.specular * pow( EdotR, 50.0));
	}
	else
	{
		color = ambient;
	}
	
	gl_FragColor = color * texture2D(tex, gl_TexCoord[0].st);
}