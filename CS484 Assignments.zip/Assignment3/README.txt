Program:	glsl_Shader	(Assignment 3)
Author:		Kyle Maysey
Email:		Kyle_Maysey@csu.fullerton.edu

Description:

	This project introduces us to the OpenGL shading language.  In this assignment we were to use GLSL to implement phong
shanding using the vertex and fragment shaders.  I provide two different fragment shaders: phong.fs and phong2.fs.  The first
fragment shader performs the phong shading blindly without taking in to account the material of the object.  phong2.fs uses
the material properties set with the openGL calls to implement the shading.


Controls:

	Left Click		- Translate in the x-y plane

	Shift + Left Click	- Translate in the x-z plane

	Control + Left Click 	- Translate in the z plane

	space			- Toggles translation of model and light source
	
	m			- Changes material used for coloring the model

	g			- Toggles the use of fixed functionality and shaders

	ESC			- Quit


How to run:

	**Originally compiled in windows using Visual Studio Express.  Used secondary libraries for glut and glew**
	
	Compile code and execute program through desired means.

	commandline argument:	-v				--to display debug messages
				-x [File Path of .vs shader]	--load vertex shader
				-f [File Path of .fs shader]	--load fragment shader

Example Commandline:

	"file path"/glsl_shader.exe -v -x "file path"/phong.vs -f "file path"/phong.fs

	OR

	"file path"/glsl_shader.exe -v -x "file path"/phong.vs -f "file path"/phong2.fs