/* Kyle Maysey
 * Kyle_Maysey@csu.fullerton.edu
 * CS 484
 * August 2012
 *
 * $Id: myShader.cpp 2399 2010-09-09 20:47:35Z mshafae $
 *
 * My simple shader; shading routine defined in the assignment description.
 */

#include "myShader.h"
#include <math.h>
#include <iostream>

#ifndef MAX
#define MAX( x, y ) ((x) >= (y) ? (x) :  (y))
#endif

void myShader( float *vertex, float *normal, float *light,
               Camera& cam, float *surfaceColor )
{
	
	float InitialColor[3] = {1.0, 1.0, 1.0};
	float PhongExp[3] = {1.0, 2.0, 20.0};

	//create light vector
	float lightVec[3];
	lightVec[0] = vertex[0] - light[0];
	lightVec[1] = vertex[1] - light[1];
	lightVec[2] = vertex[2] - light[2];

	float lVecMag = sqrt( (lightVec[0] * lightVec[0]) + (lightVec[1] * lightVec[1]) + (lightVec[2] * lightVec[2]));

	lightVec[0] /= lVecMag;
	lightVec[1] /= lVecMag;
	lightVec[2] /= lVecMag;

	//create eye vector
	float eyeVec[3];
	eyeVec[0] = vertex[0] - cam.position[0];
	eyeVec[1] = vertex[1] - cam.position[1];
	eyeVec[2] = vertex[2] - cam.position[2];

	float eyeMag = sqrt( (eyeVec[0] * eyeVec[0]) + (eyeVec[1] * eyeVec[1]) + (eyeVec[2] * eyeVec[2]));

	//normalize eye vector
	eyeVec[0] /= eyeMag;
	eyeVec[1] /= eyeMag;
	eyeVec[2] /= eyeMag;

	//calculate reflection vector
	float lDotN = (lightVec[0] * normal[0]) + (lightVec[1] * normal[1]) + (lightVec[2] * normal[2]);

	float reflVec[3];
	reflVec[0] = (-lightVec[0]) + ( 2 * lDotN * normal[0]);
	reflVec[1] = (-lightVec[1]) + ( 2 * lDotN * normal[1]);
	reflVec[2] = (-lightVec[2]) + ( 2 * lDotN * normal[2]);

	float reflMag = sqrt( (reflVec[0] * reflVec[0]) + (reflVec[1] * reflVec[1]) + (reflVec[2] * reflVec[2]));

	reflVec[0] /= reflMag;
	reflVec[1] /= reflMag;
	reflVec[2] /= reflMag;

	//Shade Vertex Color
	float eDotR = (eyeVec[0] * reflVec[0]) + (eyeVec[1] * reflVec[1]) + (eyeVec[2] * reflVec[2]);

	for (int i = 0; i < 3; i++)
		surfaceColor[i] = InitialColor[i] * fabs( pow( (eDotR + 1) / 2, PhongExp[i]));
}
