/* Your Name Here
 * somebody at something dot TLD
 * CS 484
 * October 20XX
 *
 * $Id: util.cpp 2444 2010-09-20 01:35:35Z mshafae $
 *
 * Utility routines to make life easier.
 */

#ifdef __APPLE__
/* Apple's weird location of their OpenGL & GLUT implementation */
#include <GLUT/glut.h>
#include <OpenGL/glext.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#elif WIN32
#include <Windows.h>
#include "glut.h"
#else
/* Unix, Linux, and BSD */
#include <GL/glut.h>
#endif
#include "util.h"
#include <cstdlib>


void printModelViewMatrix( void ){
  float matrix[16];
  glGetFloatv( GL_MODELVIEW_MATRIX, matrix );
  _msGfxPrintMatrix16fv( matrix );
}

void printProjectionMatrix( void ){
  float matrix[16];
  glGetFloatv( GL_PROJECTION_MATRIX, matrix );
  _msGfxPrintMatrix16fv( matrix );
}

void drawOrigin( void ){
  glBegin(GL_LINES);
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(0.0, 0.0, 0.0);
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(1.0, 0.0, 0.0);

    glColor3f(0.0, 1.0, 0.0);
    glVertex3f(0.0, 0.0, 0.0);
    glColor3f(0.0, 1.0, 0.0);
    glVertex3f(0.0, 1.0, 0.0);

    glColor3f(0.0, 0.0, 1.0);
    glVertex3f(0.0, 0.0, 0.0);
    glColor3f(0.0, 0.0, 1.0);
    glVertex3f(0.0, 0.0, 1.0);
  glEnd( );
}

int getMatrixMode( ){
  int mode;
	glGetIntegerv( GL_MATRIX_MODE, &mode );
  return( mode );
}

void loadMatrix( float matrix[16] ){
	glLoadMatrixf( matrix );
}

void topOfActiveStack( float matrix[16] ){
  int mode;
  glGetIntegerv( GL_MATRIX_MODE, &mode );
  if( mode == GL_MODELVIEW ){
    glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
  }else if( mode == GL_PROJECTION ){
    glGetFloatv(GL_PROJECTION_MATRIX, matrix);
  }else{
    fprintf( stderr, "You have activated a stack other than GL_MODELVIEW and GL_PROJECTION_MATRIX. Exiting.\n" );
    exit(1);
  }
}

