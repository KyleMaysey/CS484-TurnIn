/* Kyle Maysey
 * Kyle_Maysey@csu.fullerton.edu
 * CS 484
 * August 2012
 *
 * $Id: transformations.cpp 2408 2010-09-14 19:47:33Z mshafae $
 *
 * Replacements for the OpenGL transformations.
 */

#include "transformations.h"
#include <math.h>

void myTranslatef( GLfloat x, GLfloat y, GLfloat z )
{
	//glTranslatef(x, y, z);

	GLfloat transMatrix[16];

	for (int i = 0; i <= 15; i++)
	{
		if (( i % 5) == 0)
			transMatrix[i] = 1.0;
		else
			transMatrix[i] = 0.0;
	}

	transMatrix[12] = x;
	transMatrix[13] = y;
	transMatrix[14] = z;

	glMultMatrixf(transMatrix);

    // Get top of the active stack and store it in a matrix
    // Create my own translation matrix given x, y, z
    // multiply my matrix and the copy of the top of the stack (order matters!)
      // Take the product, overwrite the top of the stac
}

void myTranslated( GLdouble x, GLdouble y, GLdouble z )
{
	//glTranslated(x, y, z);

	GLdouble transMatrix[16];

	for (int i = 0; i <= 15; i++)
	{
		if (( i % 5) == 0)
			transMatrix[i] = 1.0;
		else
			transMatrix[i] = 0.0;
	}

	transMatrix[12] = x;
	transMatrix[13] = y;
	transMatrix[14] = z;

	glMultMatrixd(transMatrix);

}

void myScalef( GLfloat x, GLfloat y, GLfloat z )
{
	//glScalef(x, y, z);
	GLfloat transMatrix[16];
	int setScale = 0;		//flag for setting the correct scale values

	for (int i = 0; i <= 15; i++)
	{

		if (( i % 5) == 0)
		{
			if (setScale == 0)
			{
				transMatrix[i] = x;
				setScale++;
			}
			else if (setScale == 1)
			{
				transMatrix[i] = y;
				setScale++;
			}
			else if (setScale == 2)
			{
				transMatrix[i] = z;
				setScale++;
			}
			else
				transMatrix[i] = 1.0;
		}
		else
			transMatrix[i] = 0.0;

	}

	glMultMatrixf(transMatrix);

}

void myRotatef( GLfloat angle, GLfloat x, GLfloat y, GLfloat z )
{
	//glRotatef(angle, x, y, z);

	GLfloat transMatrix[16];

	GLfloat CosAngle = cos(angle);
	GLfloat OneMinusCos = (1 - CosAngle);
	GLfloat SineAngle = sin(angle);

	transMatrix[0] = x * x * OneMinusCos + CosAngle;
	transMatrix[1] = y * z * OneMinusCos + z * SineAngle;
	transMatrix[2] = x * z * OneMinusCos - y * SineAngle;
	transMatrix[3] = 0;

	transMatrix[4] = x * y * OneMinusCos - z * SineAngle;
	transMatrix[5] = y * y * OneMinusCos + CosAngle;
	transMatrix[6] = y * z * OneMinusCos + x * SineAngle;
	transMatrix[7] = 0;

	transMatrix[8] = x * z * OneMinusCos + y * SineAngle;
	transMatrix[9] = y * z * OneMinusCos - x * SineAngle;
	transMatrix[10] = z * z * OneMinusCos + CosAngle;
	transMatrix[11] = 0;

	transMatrix[12] = 0;
	transMatrix[13] = 0;
	transMatrix[14] = 0;
	transMatrix[15] = 1;

	glMultMatrixf(transMatrix);

}

void myuLookAt( GLdouble eyeX, GLdouble eyeY, GLdouble eyeZ,
                GLdouble centerX, GLdouble centerY, GLdouble centerZ,
                GLdouble upX, GLdouble upY, GLdouble upZ )
{
	//gluLookAt( eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ );
	GLdouble fVec[3];
	fVec[0] = centerX - eyeX;
	fVec[1] = centerY - eyeY;
	fVec[2] = centerZ - eyeZ;

	GLdouble fMag = sqrt( (fVec[0] * fVec[0]) + (fVec[1] * fVec[1]) + (fVec[2] * fVec[2]));

	fVec[0] /= fMag;
	fVec[1] /= fMag;
	fVec[2] /= fMag;

	GLdouble uMag = sqrt( (upX * upX) + (upY * upY) + (upZ * upZ));
	GLdouble uNorm[3];

	uNorm[0] = upX / uMag;
	uNorm[1] = upY / uMag;
	uNorm[2] = upZ / uMag;

	GLdouble sVec[3];

	sVec[0] = (fVec[1] * uNorm[2]) - (fVec[2] * uNorm[1]);
	sVec[1] = (fVec[2] * uNorm[0]) - (fVec[0] * uNorm[2]);
	sVec[2] = (fVec[0] * uNorm[1]) - (fVec[1] * uNorm[0]);

	GLdouble transMatrix[16];

	transMatrix[0] = sVec[0];
	transMatrix[1] = (sVec[1] * fVec[2]) - (sVec[2] * fVec[1]);
	transMatrix[2] = -fVec[0];
	transMatrix[3] = 0;

	transMatrix[4] = sVec[1];
	transMatrix[5] = (sVec[2] * fVec[0]) - (sVec[0] * fVec[2]);
	transMatrix[6] = -fVec[1];
	transMatrix[7] = 0;

	transMatrix[8] = sVec[2];
	transMatrix[9] = (sVec[0] * fVec[1]) - (sVec[1] * fVec[0]);
	transMatrix[10] = -fVec[2];
	transMatrix[11] = 0;

	transMatrix[12] = 0;
	transMatrix[13] = 0;
	transMatrix[14] = 0;
	transMatrix[15] = 1;

	//Now actually set up viewport
	glMultMatrixd(transMatrix);
	myTranslated(-eyeX, -eyeY, -eyeZ);


}

void myFrustum( GLdouble left, GLdouble right, GLdouble bottom,
                GLdouble top, GLdouble zNear, GLdouble zFar )
{
	//glFrustum( left, right, bottom, top, zNear, zFar );

	GLdouble transMatrix[16];

	transMatrix[0] = ( 2 * zNear) / (right - left);
	transMatrix[1] = 0;
	transMatrix[2] = 0;
	transMatrix[3] = 0;

	transMatrix[4] = 0;
	transMatrix[5] = (2 * zNear) / (top - bottom);
	transMatrix[6] = 0;
	transMatrix[7] = 0;

	transMatrix[8] = (right + left) / (right - left);
	transMatrix[9] = (top + bottom) / (top - bottom);
	transMatrix[10] = -1 * (zFar + zNear) / (zFar - zNear);
	transMatrix[11] = -1;

	transMatrix[12] = 0;
	transMatrix[13] = 0;
	transMatrix[14] = -1 * (2 * zFar * zNear) / (zFar - zNear);
	transMatrix[15] = 0;

	glMultMatrixd(transMatrix);

}

void myuPerspective( GLdouble fovy, GLdouble aspect,
                     GLdouble zNear, GLdouble zFar )
{
	//gluPerspective( fovy, aspect, zNear, zFar );

	GLdouble transMatrix[16];

	transMatrix[0] = (1/tan(fovy/2)) / (aspect);
	transMatrix[1] = 0;
	transMatrix[2] = 0;
	transMatrix[3] = 0;

	transMatrix[4] = 0;
	transMatrix[5] = (1/tan(fovy/2));
	transMatrix[6] = 0;
	transMatrix[7] = 0;

	transMatrix[8] = 0;
	transMatrix[9] = 0;
	transMatrix[10] = (zFar + zNear) / (zNear - zFar);
	transMatrix[11] = -1;

	transMatrix[12] = 0;
	transMatrix[13] = 0;
	transMatrix[14] = (2 * zFar * zNear) / (zNear - zFar);
	transMatrix[15] = 0;

	glMultMatrixd(transMatrix);

}

void myOrtho( GLdouble left, GLdouble right, GLdouble bottom,
             GLdouble top, GLdouble zNear, GLdouble zFar )
{
	//glOrtho( left, right, bottom, top, zNear, zFar );

	GLdouble transMatrix[16];

	transMatrix[0] = 2 / (right - left);
	transMatrix[1] = 0;
	transMatrix[2] = 0;
	transMatrix[3] = 0;

	transMatrix[4] = 0;
	transMatrix[5] = 2 / (top - bottom);
	transMatrix[6] = 0;
	transMatrix[7] = 0;

	transMatrix[8] = 0;
	transMatrix[9] = 0;
	transMatrix[10] = -1 * 2 / (zFar - zNear);
	transMatrix[11] = 0;

	transMatrix[12] = -1 * (right + left) / (right - left);
	transMatrix[13] = -1 * (top + bottom) / (top - bottom);
	transMatrix[14] =  -1 * (zFar + zNear) / (zFar - zNear);
	transMatrix[15] = 1;

	glMultMatrixd(transMatrix);

}
