/* Your Name Here
 * somebody at something dot TLD
 * CS 484
 * October 20XX
 *
 * $Id: Camera.h 2399 2010-09-09 20:47:35Z mshafae $
 *
 * Naive camera class.
 */

#ifndef _CAMERA_H_
#define _CAMERA_H_

// Add to this camera class as you see fit.
class Camera {
public:
  Camera( ){
    up[0] = center[0] = position[0] = 0.f;
    up[0] = center[0] = position[1] = 0.f;
    up[0] = center[0] = position[2] = 0.f;
  };
  float position[3];
  float center[3];
  float up[3];
};

#endif