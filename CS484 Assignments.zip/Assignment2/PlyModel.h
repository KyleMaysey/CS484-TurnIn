/* Your Name Here
 * somebody at something dot TLD
 * CS 484
 * October 2008
 *
 * $Id: PlyModel.h 2408 2010-09-14 19:47:33Z mshafae $
 *
 * Reads a PLY format model file and returns an indexed triangle face list.
 *
 */

#ifndef _PLYMODEL_H_
#define _PLYMODEL_H_

#include "FaceList.h"

FaceList* readPlyModel( const char* filename );

#endif