/* Your Name Here
 * somebody at something dot TLD
 * CS 484
 * October 20XX
 *
 * $Id: myShader.h 2399 2010-09-09 20:47:35Z mshafae $
 *
 * My simple shader; shading routine defined in the assignment description.
 */

#ifndef _MY_SHADER_H_
#define _MY_SHADER_H_

#include "Camera.h"

// Pass in the vertex on the surface, the normal to the vertex,
// the position of the ligh and the camera object; then calculate
// the color of the surface at that point and store it in surfaceColor
// which is passed by reference.
void myShader( float *vertex, float *normal, float *light,
               Camera& cam, float *surfaceColor );

void myFlatShader(	float *vertex, float *normal, float *light,
					Camera& cam, float *surfaceColor );
 
#endif