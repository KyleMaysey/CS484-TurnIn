/* Your Name Here
 * somebody at something dot TLD
 * CS 484
 * October 20XX
 *
 * $Id: transformations.h 2399 2010-09-09 20:47:35Z mshafae $
 *
 * Replacements for the OpenGL transformations.
 */

#ifndef _TRANSFORMATIONS_H_
#define _TRANSFORMATIONS_H_

#ifdef __APPLE__
/* Apple's weird location of their OpenGL & GLUT implementation */
#include <GLUT/glut.h>
#include <OpenGL/glext.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#elif WIN32
#include <Windows.h>
#include "glut.h"
#else
/* Unix, Linux, and BSD */
#include <GL/glut.h>
#endif

void myTranslatef( GLfloat x, GLfloat y, GLfloat z );

void myScalef( GLfloat x, GLfloat y, GLfloat z );

void myRotatef( GLfloat angle, GLfloat x, GLfloat y, GLfloat z );

void myuLookAt( GLdouble eyeX, GLdouble eyeY, GLdouble eyeZ,
                GLdouble centerX, GLdouble centerY, GLdouble centerZ,
                GLdouble upX, GLdouble upY, GLdouble upZ );

void myFrustum( GLdouble left, GLdouble right, GLdouble bottom,
                GLdouble top, GLdouble zNear, GLdouble zFar );

void myuPerspective( GLdouble fovy, GLdouble aspect,
                     GLdouble zNear, GLdouble zFar );

void myOrtho( GLdouble left, GLdouble right, GLdouble bottom,
              GLdouble top, GLdouble zNear, GLdouble zFar );

#endif