/* Your Name Here
 * somebody at something dot TLD
 * CS 484
 * October 20XX
 *
 * $Id: util.h 2400 2010-09-09 20:58:26Z mshafae $
 *
 * Utility routines to make life easier.
 */

#ifndef _UTIL_H_
#define _UTIL_H_

#include <cstdio>

// Macro to print out OpenGL matrices (float[16]) to stderr.
#define _msGfxPrintMatrix16fv( matrix ) { \
  int __glPrintMatrixIndex = 0; \
    for( __glPrintMatrixIndex = 0; __glPrintMatrixIndex < 4; __glPrintMatrixIndex++ ){ \
      fprintf( stderr, "%.5f %.5f %.5f %.5f\n", matrix[__glPrintMatrixIndex + 0], matrix[__glPrintMatrixIndex + 4], matrix[__glPrintMatrixIndex + 8], matrix[__glPrintMatrixIndex + 12] ); \
    } \
}

void printModelViewMatrix( void );

void printProjectionMatrix( void );

void drawOrigin( void );

int getMatrixMode( );

void loadMatrix( float matrix[16] );

void topOfActiveStack( float matrix[16] );

#endif