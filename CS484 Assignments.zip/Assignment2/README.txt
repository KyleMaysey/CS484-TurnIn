Program:	simple shader	(Assignment 2)
Author:		Kyle Maysey
Email:		Kyle_Maysey@csu.fullerton.edu

Description:

	This project introduces us to how openGL handles the commands for transformations and setting up viewing volumes.
An introduction to how shading is performed is also present in this assignment.  Two forms of shading are included in the program.
The user can toggle between smooth and flat shading by pressing d on the keyboard.


Controls:

	Left Click		- Translate in the x-y plane

	Shift + Left Click	- Translate in the x-z plane

	Control + Left Click 	- Dolly the camera

	up, down, left, right	- Arrow keys rotate model in respective direction

	NUM +, NUM -		- Scale model positively or negatively
	
	p			- Toggle Orthographic view or perspective view

	d			- Toggle flat shading or smooth shading

	q or ESC		- Quit


How to run:

	**Originally compiled in windows using Visual Studio Express.  Only secondary library used is glut**
	
	Compile code and execute program through desired means.

	commandline argument:	-v				--to display debug messages
				-i [File Path of .ply model]	--model to render

Example Commandline:

	"file path"/simpleshader.exe -v -i "file path"/sphere.ply