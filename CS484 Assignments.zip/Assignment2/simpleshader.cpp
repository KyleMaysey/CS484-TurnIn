/* Kyle Maysey
 * Kyle_Maysey@csu.fullerton.edu
 * CS 484
 * August 2012
 *
 * $Id: simpleshader.cpp 2421 2010-09-17 19:14:37Z mshafae $
 *
 */

#ifdef __APPLE__
/* Apple's weird location of their OpenGL & GLUT implementation */
#include <GLUT/glut.h>
#include <OpenGL/glext.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#elif WIN32
#include <Windows.h>
#include <gl\glut.h>
#include <gl\GL.h>
#include <gl\GLU.h>
#else
/* Unix, Linux, and BSD */
#include <GL/glut.h>
#endif

#include <cstring>
#include <iostream>
#include <fstream>
#include "getopt.h"
#include "FaceList.h"
#include "PlyModel.h"
#include "util.h"
#include "transformations.h"
#include "myShader.h"
#include "Camera.h"

using namespace std;

bool gIsVerbose, gSmoothShading, isOrtho;
FaceList *gModel;
float gLightPosition[3];
Camera gCamera;
float gRotation[3];
float gScale;
float gTranslate[3];
int gMouseButtonState;
int gMouseButton;
int gMouseModifiers;

void usage( string msg = "" ){
  cerr << msg.c_str( );
  cerr << "usage: simpleshader [-vh] -i inputfile" << endl;
}

void init(void){
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glFrontFace(GL_CCW);
   glEnable(GL_BLEND);
   glDisable(GL_LIGHTING);
   glEnable(GL_DEPTH_TEST);
   gLightPosition[0] = -3.0;			//originally 1.25
   gLightPosition[1] = 1.25;
   gLightPosition[2] = 1.0;			//originally .5
   gCamera.up[0] = 0.0;
   gCamera.up[1] = 1.0;
   gCamera.up[2] = 0.0;
   gCamera.position[0] = 0.0;
   gCamera.position[1] = 0.0;
   gCamera.position[2] = 1.0;
   gCamera.center[0] = 0.0;
   gCamera.center[1] = 0.0;
   gCamera.center[2] = -1.0;
   
   gRotation[0] = 0.0;
   gRotation[1] = 0.0;
   gRotation[2] = 0.0;
   
   gScale = 1.0;
   
   gTranslate[0] = 0.0;
   gTranslate[1] = 0.0;
   gTranslate[2] = 0.0;
}


void display(void){
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity( );

  myuLookAt( gCamera.position[0], gCamera.position[1], gCamera.position[2],
    gCamera.center[0], gCamera.center[1], gCamera.center[2],
    gCamera.up[0], gCamera.up[1], gCamera.up[2] );

  myRotatef( gRotation[0], 1.0, 0.0, 0.0);
  myRotatef( gRotation[1], 0.0, 1.0, 0.0 );
  myRotatef( gRotation[2], 0.0, 0.0, 1.0 );
  myScalef( gScale, gScale, gScale);
  myTranslatef( gTranslate[0], gTranslate[1], gTranslate[2] );

  if( gIsVerbose ){
    fprintf( stderr, "Model View Matrix\n" );
    printModelViewMatrix( );
    fprintf( stderr, "\nProjection Matrix\n" );
    printProjectionMatrix( );
  }
  drawOrigin( );
  glBegin(GL_TRIANGLES);
  for(unsigned int i = 0; i < gModel->faceCount( ); i++ )
  {
	  float surfaceColor[3];
	  if( gSmoothShading)
	  {
			for( unsigned int j = 0; j < 3; j++ )
			{


				if( gSmoothShading )
				{
					// Set each vertex's color to what it shoul be according
					// to that vertex's vertex normal

					// The four lines below demonstrate how to pass in the values to
					// calculate the shading but it is just for demonstration and does
					// not work correctly according to the assignment's specifications.
					myShader(	gModel->vertices[gModel->faces[i][j]], 
								gModel->vertexNormals[gModel->faces[i][j]],
								gLightPosition, gCamera, surfaceColor );
				}
		  
      
				glColor3fv( surfaceColor );
				glVertex3fv( gModel->vertices[gModel->faces[i][j]] );
			}
	  }
	  else
	  {
			  // Set each vertex to the same color as the face
			  
			  //changed first line: gModel->vertices[gModel->faces[i][j]
			  //std::cerr << "Face " << i << ": ";
			  myShader(	gModel->vertices[gModel->faces[i][0]], 
							gModel->vertexNormals[gModel->faces[i][0]],
							gLightPosition, gCamera, surfaceColor );

			  for( unsigned int j = 0; j < 3; j++)
			  {
				  glColor3fv( surfaceColor );
				  glVertex3fv( gModel->vertices[gModel->faces[i][j]] );
			  }

	  }
  }
  glEnd( );
  glFlush ();
  glutSwapBuffers();
}

void reshape( int w, int h ){
	if(gIsVerbose)
		cerr << "reshape called" << endl;

  glViewport( 0, 0, (GLsizei) w, (GLsizei) h );
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity( );

  if (isOrtho)
	  myOrtho(-1.5, 1.5, -1.5, 1.5, 1.0, 5.0);
  else
  {
	  //myuPerspective( 40.0, (GLfloat) w/(GLfloat) h, 1.0, 1.5 );
	  myFrustum( -1.5, 1.5, -1.5, 1.5, 1.0, 5.0);
  }

  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity( );
}

void mouse(int button, int state, int x, int y){
  gMouseButtonState = state;
  gMouseButton = button;
  gMouseModifiers = glutGetModifiers( );
  glutPostRedisplay( );
}

void mouseMotion( int x, int y ){
  static int sLastX = x, sLastY = y;
  // scale it down a bit
  float tx = (x - sLastX) / 32.f;
  float ty = (y - sLastY) / 32.f;
  sLastX = x;
  sLastY = y;
  
  if( gMouseButtonState == GLUT_DOWN ){
    if( gMouseModifiers == GLUT_ACTIVE_SHIFT ){
      // translate in XZ plane
      gTranslate[0] += tx;
      gTranslate[2] += ty;
    }else if( gMouseModifiers == GLUT_ACTIVE_CTRL ){
      // dolly the camera
      gCamera.position[2] += ty;
    }else{
      // No modifier key pressed in the mouse function
      // translate in XY plane
      gTranslate[0] += tx;
      gTranslate[1] -= ty;
    }
  }
  glutPostRedisplay( );
}

void keyboard(unsigned char key, int x, int y){
  switch (key) {
    case 27:
    // escape key
    case 'q':
    exit(0);
    break;
    case 'd':
    case 'D':

	gSmoothShading = !gSmoothShading;
    // toggle smooth/flat shading
    break;
    case 'p':
    case 'P':

	isOrtho = !isOrtho;

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity( );

	if (isOrtho)
		myOrtho(-1.5, 1.5, -1.5, 1.5, 1.0, 5.0);
	else
	{
		//myuPerspective( 40.0, (GLfloat) w/(GLfloat) h, 1.0, 1.5 );
		myFrustum( -1.5, 1.5, -1.5, 1.5, 1.0, 5.0);
	}

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity( );

    // toggle between orthographic and perspective projection
    break;
    case '+':
    // Positively scale the model
    gScale += 0.25;
    break;
    case '-':
    // Negatively scale the model
    gScale -= 0.25;
    break;
  }
  glutPostRedisplay( );
  
}

void special( int key, int px, int py ){
  // If you need to save what key was last pressed
  // uncomment the line below
  //static int sLastKey = key;
  if( glutGetModifiers( ) == GLUT_ACTIVE_SHIFT ){
    switch( key ){
      case GLUT_KEY_UP:
      //rotate around Z
      gRotation[2] += 25.0;
      break;
      case GLUT_KEY_DOWN:
      //rotate around Z
      gRotation[2] -= 25.0;
      break;
    }
  }else{
    switch( key ){
      case GLUT_KEY_UP:
      //rotate around X
      gRotation[0] += 25.0;
      break;
      case GLUT_KEY_DOWN:
      //rotate around X
      gRotation[0] -= 25.0;
      break;
      case GLUT_KEY_LEFT:
      //rotate around Y
      gRotation[1] -= 25.0;
      break;
      case GLUT_KEY_RIGHT:
      //rotate around Y
      gRotation[1] += 25.0;
      break;
    }
  }
  glutPostRedisplay( );
}



int main( int argc, char **argv ){
  int ch;
  char *in = NULL;
  
  static struct option longopts[] = {
    { "input", required_argument, NULL, 'i' },
    { "verbose", no_argument, NULL, 'v' },
    { "help", no_argument, NULL, 'h' },
    { NULL, 0, NULL, 0 }
  };

  gIsVerbose = false;
  gSmoothShading = false;
  gModel = NULL;

  isOrtho = false;

  if( argc < 3 ){
    usage( string( "You must specify the correct number of parameters.\n" ) );
    exit(1);
  }
  glutInit(&argc, argv);
  
  while( (ch = getopt_long(argc, argv, "i:vh", longopts, NULL)) != -1 ){
    switch( ch ){
      case 'i':
        /* input matrix file */
        in = strdup( optarg );
      break;
      case 'v':
        /* turn on verbose logging */
        gIsVerbose = true;
      break;
      case 'h':
        usage( );
        return(0);
      break;
      default:
        /* do nothing */
        fprintf( stderr, "Ignoring unknown option: %c\n", ch );
      break;
    } 
  }

  glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH );
  glutInitWindowSize( 500, 500 ); 
  glutInitWindowPosition( 100, 100 );
  glutCreateWindow( "Simple Shader" );
  
  init( );
  if( in != NULL ){
    gModel = readPlyModel( in );
  }else{
    usage( "Input file is mandatory." );
  }

  free( in );

  glutDisplayFunc( display ); 
  glutReshapeFunc( reshape );
  glutMouseFunc( mouse );
  glutMotionFunc( mouseMotion );
  glutSpecialFunc( special );
  glutKeyboardFunc( keyboard );
  glutMainLoop( );

  return(0);
}
