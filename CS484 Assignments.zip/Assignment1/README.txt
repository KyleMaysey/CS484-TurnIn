Program:	gl_bresenham
Author:		Kyle Maysey
Email:		Kyle_Maysey@csu.fullerton.edu

Description:

	This project demonstrates the use of the implicit line equation for a line pixel by pixel.  Glut is used
to set up display window.  The circles represent pixel, you begin by clicking on one pixel to select it, then clicking on
a second pixel to designate the end point.  The program then draws a best approximation of the line between these two points.


Controls:

	Left Click 	- Designates start and endpoint.
	
	c		- Clear drawn pixels

	q		- Quit


How to run:

	**Originally compiled in windows using Visual Studio Express.  Only secondary library used is glut**
	
	Compile code and execute program through desired means.

	Can use the commandline argument -v to display debug messages

Example Commandline:

	"file path"/gl_bresenham.exe -v