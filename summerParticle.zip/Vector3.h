//Author:	Kyle Maysey
//Email:	Kyle_Maysey@csu.fullerton.edu

//Vector3.h
//Purpose:	This is going to be a class template to represent 3 component vectors.
//			As scenes are represented as matrices in OpenGL, the Vector3 will
//			have a fourth component set to 0.



#ifndef VECTOR_3_KM
#define VECTOR_3_KM

#include <math.h>

template<class Type>
class Vector3
{
public:

	Vector3();										//Default Constructor
	Vector3( const Type, const Type, const Type);	//Initialization constructor
	Vector3( const Vector3<Type>&);					//Copy Constructor
	~Vector3();										//Destructor

	Type Dot( const Vector3<Type>&);				//Returns scalar product of the calling vector and parameter vector.

	Type& operator[] (const int);					//Overload array-access operator for easy value access
	Vector3<Type>& operator= (const Vector3<Type>&);//Overload assignment operator

	Vector3<Type> operator- (const Vector3<Type>&); //Overload subtraction operator

	void Norm();									//Method to normalize vector; mutates vector values

	Type V[4];		//Vector to store x,y,z coordinate. V[3] = 0
};

template<class Type>
Vector3<Type>::Vector3()
{
	//Unused as type is decided yet
}

template<class Type>
Vector3<Type>::Vector3( const Type v1, const Type v2, const Type v3)
{
	V[0] = v1;
	V[1] = v2;
	V[2] = v3;
	V[3] = (Type) 0.0;		//Defaulting to 0
}

template<class Type>
Vector3<Type>::Vector3(const Vector3<Type>& Vec)
{
	V[0] = Vec.V[0];
	V[1] = Vec.V[1];
	V[2] = Vec.V[2];
	V[3] = Vec.V[3];
}

template<class Type>
Vector3<Type>::~Vector3()
{
	//Unused
}

template<class Type>
Type& Vector3<Type>::operator[] (const int index)
{
	return V[index];
}

template<class Type>
Vector3<Type>& Vector3<Type>::operator= (const Vector3<Type>& Vec)
{
	V[0] = Vec.V[0];
	V[1] = Vec.V[1];
	V[2] = Vec.V[2];
	V[3] = Vec.V[3];

	return *this;
}

template<class Type>
Vector3<Type> Vector3<Type>::operator- (const Vector3<Type>& Vec)
{
	Vector3<Type> NewV;
	NewV.V[0] = V[0] - Vec.V[0];
	NewV.V[1] = V[1] - Vec.V[1];
	NewV.V[2] = V[2] - Vec.V[2];
	NewV.V[3] = V[3] - Vec.V[3];
	
	return NewV;
}

template<class Type>
Type Vector3<Type>::Dot( const Vector3<Type>& Vec)
{
	return ( (V[0] * Vec.V[0]) + (V[1] * Vec.V[1]) + (V[2] * Vec.V[2]) + (V[3] * Vec.V[3]));
}

template<class Type>
void Vector3<Type>::Norm()
{
	float dMag = sqrt( (V[0] * V[0]) + (V[1] * V[1]) + (V[2] * V[2]));
	//float dMag = sqrt( (V[0] * V[0]) + (V[1] * V[1]) + (V[2] * V[2]) + (V[3] * V[3]));
	
	V[0] /= dMag;
	V[1] /= dMag;
	V[2] /= dMag;
	//V[3] /= dMag;
}

typedef Vector3<float>	Vector3f;
typedef Vector3<double> Vector3d;
typedef Vector3<int>	Vector3i;

#endif