Program:	CS 484 Assignment 6: Particles Galore
Author:		Kyle Maysey
Email:		Kyle_Maysey@csu.fullerton.edu

Description:

	In this program we were to implement a simple particles system and incorporate some
typical forces and collision that occurs using particles.

	In my simulation, particles starting raining down on a plane below them.  The initial
color of the particles are purple, and color is used to signify when the particles are recreated.

	When a particle is drawn in blue, it signifies the particle was redrawn due to it's life
timer expiring.  When a particle is draw white, and given some starting x-velocity, it signifies
when a particle collided with the plane below.

	Upon creating the particle, aside from the aforementioned color signifier, particles are
also given a random starting position above the plane, as well random y-velocity.


Controls:

	R		- Resets particle information back to original state

	Z		- Resets the position of the light and simulation back to beginning state.

	SPACE		- Toggles between tranlation of the light position and simulation position.

	Left Click 	- In conjunction with moving the mouse it will translate the light source, or alter simulation position
			  in the XY plane.

			Modifiers:
			
				- Control:	If control is held down it will restrict movement to the z-axis
			
				- Shift:	If shift is held down translation happens on the x and z axis.
	

	Esc		- Quit application


How to run:

	1) In the command prompt, make the folder containing "particles.exe" your working directory
	
	2) Now call "particles.exe" to run the project.


Example command line:

	gameworld [-hv]
