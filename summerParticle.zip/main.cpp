//Author:	Kyle Maysey
//email:	Kyle_Maysey@csu.fullerton.edu

//Purpose:	Testing the use of particles

#include "particle.h"
#include <iostream>
#include <cstdio>
#include <cstdlib>
#ifdef __APPLE__
/* Apple's weird location of their OpenGL & GLUT implementation */
#include <GLUT/glut.h>
#include <OpenGL/OpenGL.h>
#include <OpenGL/glext.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include <Windows.h>
#include <gl\glew.h>
#include <gl\GL.h>
#include <gl\glut.h>
#include <gl\GLU.h>
#endif

#include <string>

#include "GLSLShader.h"		//Shader loading code provided by Professor Michael Shafae
#include "getopt.h"
#include "misc.h"
#include "Camera.h"
#include "Vector3.h"

#include "glm.h"

#define MAX_PARTICLES 1000

particle particles[MAX_PARTICLES];

bool gIsVerbose;
GLSLProgram *gProgram;
double lSpin = 0;
int gMaterialMode;
bool gShaderEnabled;
bool mLight;
bool motionReset;
int gMouseButtonState;
int gMouseButton;
int gMouseModifiers;
float lTranslate[3];
float mTranslate[3];
float cPosition[3];
float thePlane[4][3];
float pNormal[3];
GLuint loop;
float pDistance = -30.0f;
float	slowdown=2.0f;				// Slow Down Particles

Camera gCam;

//Texture Information
int iheight, iwidth, pheight, pwidth;
unsigned char* image = NULL;
unsigned char* planeImage = NULL;
GLuint TheTexture[2];		//Texture name for binding and use with GLSL

using namespace std;

void shaderInit( const char *vsFile, const char *fsFile ){

  VertexShader vertexShader( vsFile );
  FragmentShader fragmentShader( fsFile );

  gProgram = new GLSLProgram( );
  
  if( !(gProgram->attach( vertexShader )) ){
    fprintf( stderr, "Couldn't attach the vertex shader to the program\n" );
  }
  if( !(gProgram->attach( fragmentShader )) ){
    fprintf( stderr, "Couldn't attach the fragment shader to the program\n" );
  }
  
  if( !(gProgram->link( )) ){
    fprintf( stderr, "Couldn't link the shader.\n" );
  }

  if( !(gProgram->activate( )) ){
    fprintf( stderr, "Unable to activate the shader.\n" );
  }

  gProgram->isHardwareAccelerated( );

}

/*  Initialize material property, light source, lighting model,
 *  and depth buffer.
 */
void init( void ){

   glClearColor(0.0, 0.0, 0.0, 0.0);
   glShadeModel(GL_SMOOTH);
   glEnable(GL_LIGHTING);
   glEnable(GL_LIGHT0);
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_BLEND);									// Enable Blending
   glBlendFunc(GL_SRC_ALPHA,GL_ONE);					// Type Of Blending To Perform

   glGenTextures(2, TheTexture);
   glActiveTexture(GL_TEXTURE0);

   glBindTexture(GL_TEXTURE_2D, TheTexture[0]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
   glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, iwidth, iheight, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

   glBindTexture(GL_TEXTURE_2D, TheTexture[1]);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
   glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, pwidth, pheight, 0, GL_RGB, GL_UNSIGNED_BYTE, planeImage);

   for (loop=0;loop<MAX_PARTICLES;loop++)				// Initials All The Textures
	{
		particles[loop].active=true;								// Make All The Particles Active
		particles[loop].life=1.0f;								// Give All The Particles Full Life
		particles[loop].fade=float(rand()%100)/1000.0f;			// Random Fade Speed

		particles[loop].r= 1.0f;								// Select red color
		particles[loop].g= 0.0f;								// Select green color
		particles[loop].b= 1.0f;								// Select blue color

		particles[loop].x= float((rand() % 10) - 5.0f);			// Center On X Axis

		particles[loop].xv=0.0f;								// Random Speed On X Axis
		particles[loop].yv=float((rand()%50)-25.0f);		// Random Speed On Y Axis
		particles[loop].zv=0.0f;								// Random Speed On Z Axis

		particles[loop].xg=0.0f;								// Set Horizontal "gravity"
		particles[loop].yg=-1.0f;								// Set Vertical gravity
		particles[loop].zg=0.0f;								// Set Z-axis "gravity"
	}

   GLint TheSampler;
   //glUseProgram(gProgram->_object);
   TheSampler = glGetUniformLocation((gProgram->_object), "tex");	//Get location of uniform variable for texture sampler
   glUniform1i(TheSampler, 0);			//Send the value 0 to shader, indicates the use of GL_TEXTURE0 texture unit

   mLight = true;
   gShaderEnabled = true;
   gMaterialMode = 0;
   material(gMaterialMode);

   lTranslate[0] = 0.0;
   lTranslate[1] = 0.0;
   lTranslate[2] = -40.0;

   mTranslate[0] = 0.0;
   mTranslate[1] = 0.0;
   mTranslate[2] = 0.0;

   Vector3<double> camPos(0.0, 0.0, 5.0);
   Vector3<double> camUp(0.0, 1.0, 0.0);
   Vector3<double> camDir(0.0, 0.0, -1.0);
   gCam.Position = camPos;
   gCam.Up = camUp;
   gCam.Direction = camDir;

   //originally y is at -5.0
   thePlane[0][0] = -5.0;
   thePlane[0][1] = -3.0;
   thePlane[0][2] = -5.0 + pDistance;

   thePlane[1][0] = -5.0;
   thePlane[1][1] = -3.0;
   thePlane[1][2] = 5.0 + pDistance;

   thePlane[2][0] = 5.0;
   thePlane[2][1] = -3.0;
   thePlane[2][2] = -5.0 + pDistance;

   thePlane[3][0] = 5.0;
   thePlane[3][1] = -3.0;
   thePlane[3][2] = 5.0 + pDistance;

   float tempVec1[3], tempVec2[3];
   tempVec1[0]= thePlane[1][0]- thePlane[0][0];
   tempVec1[1]= thePlane[1][1]- thePlane[0][1];
   tempVec1[2]= thePlane[1][2]- thePlane[0][2];

   tempVec2[0]= thePlane[2][0]- thePlane[0][0];
   tempVec2[1]= thePlane[2][1]- thePlane[0][1];
   tempVec2[2]= thePlane[2][2]- thePlane[0][2];

   crossProduct(tempVec1, tempVec2, pNormal);
   vecNormalize(pNormal);
}

/*  Here is where the light position is reset after the modeling
 *  transformation (glRotated) is called.  This places the
 *  light at a new position in world coordinates.  The cube
 *  represents the position of the light.
 */
void display(void){
   GLfloat position[] = { 0.0, 0.0, 1.5, 1.0 };

   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glPushMatrix ();

   //Altered below from gluLookAt(0.0, 0.0, -15.0, ...)
   gluLookAt (	gCam.Position[0], gCam.Position[1], gCam.Position[2], 
					gCam.Position[0] + gCam.Direction[0], gCam.Direction[1], gCam.Direction[2], 
					gCam.Up[0], gCam.Up[1], gCam.Up[2]);

   glPushMatrix ();
		glRotated( lSpin, 1.0, 0.0, 0.0 );
		glTranslated(-lTranslate[0], lTranslate[1], lTranslate[2]);
		glLightfv (GL_LIGHT0, GL_POSITION, position);

		glTranslated (0.0, 0.0, 1.5);
		glDisable (GL_LIGHTING);
		gProgram->deactivate();
		glColor3f (0.0, 1.0, 1.0);
		glutWireCube(0.1);
		gProgram->activate();
   glPopMatrix ();

   glPushMatrix();
		glTranslated(-mTranslate[0], mTranslate[1], mTranslate[2]);

		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, TheTexture[1]);
		glColor4f(0.5, 0.25, 0.0, 1.0);
		glBegin(GL_TRIANGLE_STRIP);
   
			glNormal3fv(pNormal);

			glTexCoord2d(1,1); glVertex3fv(thePlane[0]);	//Top Right
			glTexCoord2d(0,1); glVertex3fv(thePlane[1]);	//Top Left
			glTexCoord2d(1,0); glVertex3fv(thePlane[2]);
			glTexCoord2d(0,0); glVertex3fv(thePlane[3]);
		
		glEnd();
   
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, TheTexture[0]);
		for(loop = 0; loop < MAX_PARTICLES; loop++)
		{
			if (particles[loop].active)
			{
				float x=particles[loop].x;						// Grab Our Particle X Position
				float y=particles[loop].y;						// Grab Our Particle Y Position
				float z=particles[loop].z + pDistance;					// Particle Z Pos + Zoom

				// Draw The Particle Using Our RGB Values, Fade The Particle Based On It's Life
				glColor4f(particles[loop].r,particles[loop].g,particles[loop].b,particles[loop].life);

				glBegin(GL_TRIANGLE_STRIP);						// Build Quad From A Triangle Strip
					glNormal3f(0.0, 0.0, -1.0);
					glTexCoord2d(1,1); glVertex3f(x+0.5f,y+0.5f,z); // Top Right
					glTexCoord2d(0,1); glVertex3f(x-0.5f,y+0.5f,z); // Top Left
					glTexCoord2d(1,0); glVertex3f(x+0.5f,y-0.5f,z); // Bottom Right
					glTexCoord2d(0,0); glVertex3f(x-0.5f,y-0.5f,z); // Bottom Left
				glEnd();										// Done Building Triangle Strip

				particles[loop].x+=particles[loop].xv/(slowdown*1000);// Move On The X Axis By X Speed
				particles[loop].y+=particles[loop].yv/(slowdown*1000);// Move On The Y Axis By Y Speed
				particles[loop].z+=particles[loop].zv/(slowdown*1000);// Move On The Z Axis By Z Speed

				particles[loop].xv+=particles[loop].xg;			// Take Pull On X Axis Into Account
				particles[loop].yv+=particles[loop].yg;			// Take Pull On Y Axis Into Account
				particles[loop].zv+=particles[loop].zg;			// Take Pull On Z Axis Into Account
				particles[loop].life-=particles[loop].fade;		// Reduce Particles Life By 'Fade'

				if (particles[loop].life<0.0f)					// If Particle Is Burned Out
				{
					particles[loop].life=2.0f;					// Give It New Life
					particles[loop].fade=float(rand()%100)/1000.0f;	// Random Fade Value
					particles[loop].x= float((rand() % 10) - 5.0f);						// Center On X Axis
					particles[loop].y=0.0f;						// Center On Y Axis
					particles[loop].z=0.0f;						// Center On Z Axis
					particles[loop].xv= 0.0;	// X Axis Speed And Direction
					particles[loop].yv=float((rand()%60)-30.0f);	// Y Axis Speed And Direction
					particles[loop].zv= 0.0f;	// Z Axis Speed And Direction
					particles[loop].r= 0.0f;			// Select Red From Color Table
					particles[loop].g= 0.0f;			// Select Green From Color Table
					particles[loop].b= 1.0f;			// Select Blue From Color Table
				}


				float tempVec[3] = {particles[loop].x, particles[loop].y, particles[loop].z + pDistance} ;
				vecDifference(tempVec, thePlane[0], tempVec);
			
				float dotProd = (tempVec[0] * pNormal[0]) + (tempVec[1] * pNormal[1]) + (tempVec[2] * pNormal[2]);
				//If particles is on the negative side of the plane, we have a collision
				//Redraw particle white with some x-velocity now
				if (dotProd < 0)
				{
					particles[loop].life=1.0f;					// Give It New Life
					particles[loop].fade=float(rand()%100)/1000.0f+0.003f;	// Random Fade Value
					particles[loop].x= float((rand() % 10) - 5.0f);	// Center On X Axis
					particles[loop].y=0.0f;							// Center On Y Axis
					particles[loop].z=0.0f;							// Center On Z Axis
					particles[loop].xv= float((rand()%50)-25.0f);	// X Axis Speed And Direction
					particles[loop].yv=float((rand()%60)+30.0f);	// Y Axis Speed And Direction
					particles[loop].zv= 0.0f;			// Z Axis Speed And Direction
					particles[loop].r= 1.0f;			// Select Red From Color Table
					particles[loop].g= 1.0f;			// Select Green From Color Table
					particles[loop].b= 1.0f;			// Select Blue From Color Table
				}

			}
		}

	glPopMatrix();

   glPopMatrix ();
   glFlush ();
   glutSwapBuffers();

   glDisable(GL_TEXTURE_2D);

   GLenum ErrorCode;
   const GLubyte* ErrorString;

   while((ErrorCode = glGetError()) != GL_NO_ERROR)
   {
	   ErrorString = gluErrorString(ErrorCode);
	   fprintf(stderr, "OpenGL Error: %s\n", ErrorString);
   }

}

//Idle function for glut
void animate(void)
{
	glutPostRedisplay();
}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(40.0, (GLfloat) w/(GLfloat) h, 1.0, 50.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void mouse(int button, int state, int x, int y)
{
	gMouseButtonState = state;
	gMouseButton = button;
	gMouseModifiers = glutGetModifiers( );
	glutPostRedisplay( );
}

void mouseMotion( int x, int y ){
  static int sLastX = x, sLastY = y;
  // scale it down a bit
  if (motionReset)
  {
	  sLastX = x;
	  sLastY = y;
	  motionReset = false;
  }
  float tx = (x - sLastX) / 32.f;
  float ty = (y - sLastY) / 32.f;
  sLastX = x;
  sLastY = y;
  
  if( gMouseButtonState == GLUT_DOWN ){
    if( gMouseModifiers == GLUT_ACTIVE_SHIFT ){
      // translate in XZ plane
		if (mLight)
		{
			lTranslate[0] -= tx;
			lTranslate[2] += ty;
		}
		else
		{
			mTranslate[0] -= tx;
			mTranslate[2] += ty;
		}
    }else if( gMouseModifiers == GLUT_ACTIVE_CTRL ){
		if (mLight)
			lTranslate[2] += ty;
		else
			mTranslate[2] += ty;
    }else{
      // No modifier key pressed in the mouse function
      // translate in XY plane
		if(mLight)
		{
			lTranslate[0] -= tx;
			lTranslate[1] -= ty;
		}
		else
		{
			mTranslate[0] -= tx;
			mTranslate[1] -= ty;
		}
    }
  }
  glutPostRedisplay( );
}

void keyboard(unsigned char key, int x, int y){
   switch (key) {
		case 32:
			mLight = !mLight;
		break;
		case 27:
         exit(0);
         break;
       case 'c':
       case 'C':
       break;
       case 'G':
       case 'g':
       break;
	   case 'r':
	   case 'R':

		   if(gIsVerbose)
			   cout << "Reset particle data." << endl << endl;

			for (loop=0;loop<MAX_PARTICLES;loop++)				// Initials All The Textures
			{
				particles[loop].active=true;								// Make All The Particles Active
				particles[loop].life=1.0f;								// Give All The Particles Full Life
				particles[loop].fade=float(rand()%100)/1000.0f;			// Random Fade Speed

				particles[loop].r= 1.0f;								// Select red color
				particles[loop].g= 0.0f;								// Select green color
				particles[loop].b= 1.0f;								// Select blue color

				particles[loop].x= float((rand() % 10) - 5.0f);			// Center On X Axis
				particles[loop].y= 0.0f;

				particles[loop].xv=0.0f;								// Random Speed On X Axis
				particles[loop].yv=float((rand()%50)-25.0f);		// Random Speed On Y Axis
				particles[loop].zv=0.0f;								// Random Speed On Z Axis

				particles[loop].xg=0.0f;								// Set Horizontal "gravity"
				particles[loop].yg=-1.0f;								// Set Vertical gravity
				particles[loop].zg=0.0f;								// Set Z-axis "gravity"
			}
			break;
	   case 'z':
	   case 'Z':
		   if(gIsVerbose)
			   cout << "Reset light and model positions." << endl << endl;
			lTranslate[0] = 0.0;
			lTranslate[1] = 0.0;
			lTranslate[2] = -40.0;

			mTranslate[0] = 0.0;
			mTranslate[1] = 0.0;
			mTranslate[2] = 0.0;

			motionReset = true;
		   break;
       case 'M':
       case 'm':
         ++gMaterialMode;
         gMaterialMode = gMaterialMode % 3;
         material(gMaterialMode);
       break;
	   case 'W':
	   case 'w':
		   cPosition[2] += 1.0;
		   break;
	   case 'S':
	   case 's':
		   cPosition[2] -= 1.0;
		   break;
	   case 'A':
	   case 'a':
		   cPosition[0] -= 1.0;
		   break;
	   case 'D':
	   case 'd':
		   cPosition[0] += 1.0;
		   break;

   }
   glutPostRedisplay();
}

void special( int key, int px, int py )
{
	// If you need to save what key was last pressed
	// uncomment the line below
	//static int sLastKey = key;
	switch( key )
	{
		case GLUT_KEY_UP:
		//rotate around X
			lSpin += 30.0;
			lSpin = fmod(lSpin, 360.0);
		break;
		case GLUT_KEY_DOWN:
		//rotate around X
			lSpin -= 30.0;
			lSpin = fmod(lSpin, 360.0);
      break;
    }
	glutPostRedisplay( );
}

void usage( string msg = "" ){
  cerr << msg.c_str( );
  cerr << "usage:	particles [-hv]" << endl;
  cerr << "			[] brackets used to indentify optional arguments" << endl << endl;
}

int main(int argc, char** argv){
  int ch;
  char* in = NULL;
  string vertexShaderSrc, fragmentShaderSrc;
  
  static struct option longopts[] = {
    { "fragmentshader", required_argument, NULL, 'f' },
    { "vertexshader", required_argument, NULL, 'x' },
    { "combo", required_argument, NULL, 'c' },
    { "verbose", no_argument, NULL, 'v' },
    { "help", no_argument, NULL, 'h' },
    { NULL, 0, NULL, 0 }
  };
  
  gIsVerbose = false;
  motionReset = false;
  
   glutInit(&argc, argv);
   while( (ch = getopt_long(argc, argv, "vh", longopts, NULL)) != -1 ){
     switch( ch ){
       case 'v':
         /* turn on verbose logging */
         gIsVerbose = true;
       break;
       case 'h':
         usage( );
         return(0);
       break;
       default:
         /* do nothing */
         fprintf( stderr, "Ignoring unknown option: %c\n", ch );
       break;
     } 
   }
   
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(800, 800); 
   glutInitWindowPosition(100, 100);
   glutCreateWindow("GLSL Shader");
#ifdef __APPLE__
   if( supportsOpenGLVersion( 2, 0 ) ){
     fprintf( stderr, "Congrats! OpenGL Shading Language is supported.\n" );
   }else{
     fprintf( stderr, "OpenGL Shading Language not supported. Sorry.\n" );
     exit(1);
   }
   if( gProgram->isHardwareAccelerated( ) ){
     fprintf( stderr, "Oh and it's hardware accelerated!\n" );
   }
#else
   GLenum err = glewInit();
   if( GLEW_OK != err ){
     /* Problem: glewInit failed, something is seriously wrong. */
     fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
     exit(1);
   }
   if( GLEW_VERSION_2_0 ){
     fprintf( stderr, "Congrats! OpenGL Shading Language is supported.\n" );
   }else{
     fprintf( stderr, "OpenGL Shading Language not supported. Sorry.\n" );
     exit(1);
   }
#endif

   image = glmReadPPM("images\\Particle.ppm", &iwidth, &iheight);
   planeImage = glmReadPPM("images\\RoofTop.ppm", &pwidth, &pheight);

	vertexShaderSrc = "shaders\\phong.vs";
	fragmentShaderSrc = "shaders\\phong.fs";
   
   //flipped init() to come after shaderInit() so glGetUnifromLocation will operate as intended
   shaderInit( vertexShaderSrc.c_str( ), fragmentShaderSrc.c_str( ) );

   init( );

   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutMouseFunc(mouse);
   glutMotionFunc( mouseMotion );
   glutSpecialFunc( special );
   glutKeyboardFunc(keyboard);
   glutIdleFunc(animate);
   glutMainLoop( );
   return( 0 );
}