//Author:	Kyle Maysey
//Email:	Kyle_Maysey@csu.fullerton.edu

//Purpose:	A class to handle all information regarding particles.  To be used with OpenGL.
//			Developed from tutorial found at http://nehe.gamedev.net/tutorial/particle_engine_using_triangle_strips/21001/

class particle
{
public:

	bool active;	//True = active, false = dead
	float life;		//Length particle is displayed
	float fade;		//How bright particle is

	float r;		//red intesity of particle
	float g;		//green intesity of particle
	float b;		//blue intesity of particle

	float x;		//particle x position
	float y;
	float z;

	float xv;		//x velocity
	float yv;
	float zv;

	float xg;		//Can be thought of as gravity, more like dampening
	float yg;
	float zg;

};