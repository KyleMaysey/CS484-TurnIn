//Author:	Kyle Maysey
//Email:	Kyle_Maysey@csu.fullerton.edu

//Camera.h
//Purpose:	This is going to be a class template to represent a Camera.
//			Compromised of 3 Vector3s.  Will comprise of a position vector,
//			an up  vector, and a direction vector



#ifndef CAMERA_KM
#define CAMERA_KM

#include "Vector3.h"

class Camera
{
public:
	Vector3d Position;
	Vector3d Direction;
	Vector3d Up;
};

#endif