//Assignment 3: GLSL
//Phong illumination - Fragment shader
//Author: Kyle Maysey

varying vec3 Normal, LightVec, HalfVec, ReflVec, Vert;

uniform sampler2D tex;

void main()
{
	//vec4 color = vec4(0.0, 1.0, 0.0, 1.0);	//Hopefully the vec3 will ignore the alpha with no issues
	vec4 color =  vec4(texture2D(tex, gl_TexCoord[0].st));
	vec4 ambient = vec4( 0.0, 0.0, 0.0, 1.0);		//Increased ambient to .1 from .01
	float NdotL, NdotH, EdotR;						//Variables used to store the dot products of variables

	vec3 EyeVec = normalize( -Vert );

	NdotL = max( dot(Normal, LightVec), 0.0);

	if(NdotL > 0.0)
	{
		//NdotH = max( dot( Normal, HalfVec), 0.0);	//Not using half vector as it creates a flare of some sort
		EdotR = max( dot( EyeVec, ReflVec), 0.0);

		color = ambient + (color * NdotL) +  (color * pow( EdotR, 32.0));
	}
	else
	{
		color = ambient;
	}
	
	//gl_FragColor = color * texture2D(tex, gl_TexCoord[0].st) * gl_Color;
	gl_FragColor = color * gl_Color;
}