//Assignment 3: GLSL
//toon illumination - Fragment shader
//Author: Kyle Maysey

varying vec3 Normal, LightVec;

uniform sampler2D tex;

void main()
{
	//vec4 color =  vec4(texture2D(tex, gl_TexCoord[0].st));
	vec4 color;
	float intensity;							//Variables used to store the dot products of variables

	intensity = dot( normalize(LightVec), normalize(Normal));

	if(intensity > 0.95)
	{
		color = vec4(1.0, 0.5, 0.5, 1.0);
	}
	else if (intensity > 0.5)
	{
		color = vec4(0.6, 0.3, 0.3, 1.0);
	}
	else if (intensity > 0.25)
	{
		color = vec4(0.4, 0.2, 0.2, 1.0);
	}
	else
	{
		color = vec4(0.2, 0.1, 0.1, 1.0);
	}
	
	gl_FragColor = color * texture2D(tex, gl_TexCoord[0].st);
	//gl_FragColor = color;
}